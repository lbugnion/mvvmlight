﻿namespace $safeprojectname$
{
    public sealed partial class TestUserControl
    {
        public TestUserControl()
        {
            InitializeComponent();
        }
    }
}